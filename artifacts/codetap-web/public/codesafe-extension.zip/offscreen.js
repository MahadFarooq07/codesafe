"use strict";
(() => {
  // src/background/offscreen.ts
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type !== "OFFSCREEN_COPY") return;
    const ta = document.createElement("textarea");
    ta.value = msg.payload;
    document.body.append(ta);
    ta.select();
    document.execCommand("copy");
    ta.remove();
  });
})();
