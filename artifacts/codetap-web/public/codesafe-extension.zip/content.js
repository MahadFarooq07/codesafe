"use strict";
(() => {
  // src/content/detect.ts
  var NAME_RE = /(otp|one[-_ ]?time|verif|passcode|security[-_ ]?code|auth[-_ ]?code|confirm(ation)?[-_ ]?code|2fa|mfa|totp|\bpin\b|\bcode\b|\bdigit)/i;
  var TEXT_TYPES = /* @__PURE__ */ new Set(["text", "tel", "number", "password", ""]);
  function isOtpInput(el) {
    if (!(el instanceof HTMLInputElement)) return false;
    if (!TEXT_TYPES.has(el.type)) return false;
    if (el.disabled || el.readOnly) return false;
    if (el.autocomplete === "one-time-code") return true;
    const label = [
      el.name,
      el.id,
      el.placeholder,
      el.getAttribute("aria-label"),
      el.getAttribute("aria-labelledby") ? labelledByText(el) : "",
      el.getAttribute("data-testid"),
      el.getAttribute("data-test"),
      el.className
    ].filter(Boolean).join(" ");
    if (NAME_RE.test(label)) return true;
    if (el.inputMode === "numeric" && el.maxLength > 0 && el.maxLength <= 8) return true;
    if (el.maxLength === 1 && (el.inputMode === "numeric" || el.pattern.includes("0-9") || el.type === "tel")) return true;
    const associated = associatedLabelText(el);
    return associated ? NAME_RE.test(associated) : false;
  }
  function labelledByText(el) {
    const ids = (el.getAttribute("aria-labelledby") ?? "").split(/\s+/);
    return ids.map((id) => document.getElementById(id)?.textContent ?? "").join(" ");
  }
  function associatedLabelText(el) {
    const parts = [];
    el.labels?.forEach((l) => parts.push(l.textContent ?? ""));
    return parts.join(" ").slice(0, 200);
  }
  function otpGroup(el) {
    if (el.maxLength !== 1) return [el];
    const root = el.form ?? el.closest("fieldset, [role=group], div, section") ?? document.body;
    const boxes = Array.from(root.querySelectorAll("input")).filter(
      (i) => i.maxLength === 1 && TEXT_TYPES.has(i.type) && i.offsetParent !== null
    );
    if (boxes.length >= 4 && boxes.length <= 8) return boxes;
    const parent = root.parentElement;
    if (parent) {
      const wider = Array.from(parent.querySelectorAll("input")).filter(
        (i) => i.maxLength === 1 && TEXT_TYPES.has(i.type) && i.offsetParent !== null
      );
      if (wider.length >= 4 && wider.length <= 8) return wider;
    }
    return [el];
  }

  // src/content/fill.ts
  var nativeSetter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
  function setValue(input, value) {
    if (nativeSetter) nativeSetter.call(input, value);
    else input.value = value;
    input.dispatchEvent(new InputEvent("input", { bubbles: true, data: value, inputType: "insertText" }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }
  function fillBox(box, ch) {
    box.focus();
    box.dispatchEvent(new KeyboardEvent("keydown", { key: ch, bubbles: true }));
    setValue(box, ch);
    box.dispatchEvent(new KeyboardEvent("keyup", { key: ch, bubbles: true }));
  }
  function fillCode(target, code, group) {
    if (group.length > 1) {
      const chars = code.split("");
      group.forEach((box, i) => {
        if (i < chars.length) fillBox(box, chars[i]);
      });
      const last = group[Math.min(chars.length, group.length) - 1];
      last?.focus();
      return;
    }
    target.focus();
    setValue(target, code);
    target.setSelectionRange?.(code.length, code.length);
  }

  // src/shared/tokens.ts
  var TOKENS_CSS = `
:host, :root {
  --bg: #ffffff;
  --bg-page: #fbfdff;
  --bg-hover: #f5f5f7;
  --text: #1b1c1d;
  --text-2: #6e6e73;
  --hairline: rgba(0, 0, 0, 0.08);
  --accent: #0a84ff;
  --success: #34c759;
  --danger: #ff3b30;
  --r-input: 12px;
  --r-card: 16px;
  --r-pill: 999px;
  --shadow-float: 0 1px 2px rgba(0, 0, 0, 0.04), 0 8px 24px rgba(0, 0, 0, 0.08);
  --ease: cubic-bezier(0.2, 0.8, 0.2, 1);
  --font: -apple-system, BlinkMacSystemFont, "SF Pro Text", "SF Pro Display", "Helvetica Neue", Inter, "Segoe UI", Roboto, sans-serif;
}
`;

  // src/content/pill.ts
  var CSS = `
${TOKENS_CSS}
:host { all: initial; }
.pill {
  position: fixed;
  z-index: 2147483647;
  display: inline-flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 2px;
  min-width: 96px;
  height: 46px;
  padding: 0 16px;
  margin: 0;
  background: var(--bg);
  color: var(--text);
  border: 0.5px solid rgba(0, 0, 0, 0.12);
  border-radius: 12px;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05), 0 6px 20px rgba(0, 0, 0, 0.10);
  font-family: var(--font);
  -webkit-font-smoothing: antialiased;
  cursor: pointer;
  user-select: none;
  white-space: nowrap;
  text-align: center;
  outline: none;
  opacity: 0;
  transform: translateY(4px) scale(0.98);
  transition: opacity 0.18s var(--ease), transform 0.18s var(--ease), background 0.12s var(--ease);
}
.pill.in { opacity: 1; transform: none; }
.pill:hover { background: var(--bg-hover); }
.pill:active { transform: scale(0.97); }
.pill:focus-visible { box-shadow: 0 0 0 3px rgba(10, 132, 255, 0.35); }
.pill.wait { cursor: default; }
.from { font-size: 11px; line-height: 1; font-weight: 500; color: var(--text-2); letter-spacing: 0; }
.code { font-size: 17px; line-height: 1.1; font-weight: 600; letter-spacing: 0.06em; font-variant-numeric: tabular-nums; }
.dots { display: inline-flex; gap: 4px; }
.dots i { width: 5px; height: 5px; border-radius: 50%; background: var(--text-2); opacity: 0.3; animation: codesafe-dot 1.1s infinite var(--ease); }
.dots i:nth-child(2) { animation-delay: 0.15s; }
.dots i:nth-child(3) { animation-delay: 0.3s; }
@keyframes codesafe-dot { 0%, 100% { opacity: 0.25 } 40% { opacity: 0.9 } }
@media (prefers-reduced-motion: reduce) {
  .pill { transition: none; }
  .dots i { animation: none; opacity: 0.6; }
}
`;
  function esc(s) {
    return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c] ?? c);
  }
  var Pill = class {
    constructor(anchor, onPick) {
      this.anchor = anchor;
      this.onPick = onPick;
      const style = document.createElement("style");
      style.textContent = CSS;
      this.el.className = "pill";
      this.el.type = "button";
      this.el.setAttribute("aria-live", "polite");
      this.el.addEventListener("mousedown", (e) => e.preventDefault());
      this.el.addEventListener("click", () => this.onPick());
      this.root.append(style, this.el);
      document.documentElement.append(this.host);
      this.position();
      window.addEventListener("scroll", this.position, true);
      window.addEventListener("resize", this.position);
    }
    anchor;
    onPick;
    host = document.createElement("codesafe-pill");
    root = this.host.attachShadow({ mode: "closed" });
    el = document.createElement("button");
    removed = false;
    searching() {
      this.el.className = "pill wait";
      this.el.setAttribute("aria-label", "Checking Gmail for a code");
      this.el.innerHTML = `<span class="dots" aria-hidden="true"><i></i><i></i><i></i></span>`;
      this.show();
    }
    found(code) {
      this.el.className = "pill";
      this.el.setAttribute("aria-label", `Paste code ${code} from Gmail`);
      this.el.innerHTML = `<span class="from">From Gmail</span><span class="code">${esc(code)}</span>`;
      this.show();
    }
    filled() {
      this.destroy();
    }
    show() {
      requestAnimationFrame(() => this.el.classList.add("in"));
      this.position();
    }
    position = () => {
      if (this.removed) return;
      const r = this.anchor.getBoundingClientRect();
      const h = 46;
      const gap = 8;
      let top = r.top - h - gap;
      if (top < 8) top = r.bottom + gap;
      const left = Math.max(8, Math.min(r.left, window.innerWidth - 8 - this.el.offsetWidth));
      this.el.style.left = `${left}px`;
      this.el.style.top = `${top}px`;
    };
    destroy() {
      if (this.removed) return;
      this.removed = true;
      window.removeEventListener("scroll", this.position, true);
      window.removeEventListener("resize", this.position);
      this.el.classList.remove("in");
      setTimeout(() => this.host.remove(), 200);
    }
  };

  // src/content/index.ts
  var active = null;
  function clear() {
    active?.pill.destroy();
    active = null;
  }
  function render(state) {
    if (!active || !state) return;
    if (state.status === "searching") active.pill.searching();
    else if (state.status === "found") active.pill.found(state.code.code);
    else clear();
  }
  function send(msg) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(msg, (r) => {
          void chrome.runtime.lastError;
          resolve(r);
        });
      } catch {
        resolve(void 0);
      }
    });
  }
  async function pick() {
    if (!active) return;
    const current = active;
    const state = await send({ type: "GET_STATE" });
    if (state?.status === "found") {
      fillCode(current.input, state.code.code, current.group);
      current.pill.filled();
      active = null;
    }
  }
  document.addEventListener(
    "focusin",
    (e) => {
      const t = e.target;
      if (!isOtpInput(t)) return;
      if (active && (active.input === t || active.group.includes(t))) return;
      clear();
      const group = otpGroup(t);
      const pill = new Pill(t, () => void pick());
      active = { input: t, group, pill };
      void send({ type: "OTP_FIELD_FOCUSED" }).then(render);
    },
    true
  );
  document.addEventListener(
    "focusout",
    () => {
      setTimeout(() => {
        if (!active) return;
        const el = document.activeElement;
        if (!(el instanceof HTMLInputElement) || !active.group.includes(el)) clear();
      }, 150);
    },
    true
  );
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === "STATE") render(msg.payload);
    if (msg.type === "PASTE_CODE") {
      const el = document.activeElement;
      if (el instanceof HTMLInputElement) {
        fillCode(el, msg.payload, otpGroup(el));
        if (active) {
          active.pill.filled();
          active = null;
        }
      }
    }
  });
})();
