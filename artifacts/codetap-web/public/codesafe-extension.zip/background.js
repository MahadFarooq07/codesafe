// src/background/auth.ts
async function getToken(interactive) {
  try {
    const { token } = await chrome.identity.getAuthToken({ interactive });
    return token ?? null;
  } catch {
    return null;
  }
}
async function getEmail(token) {
  const r = await fetch("https://gmail.googleapis.com/gmail/v1/users/me/profile", {
    headers: { Authorization: `Bearer ${token}` }
  });
  if (!r.ok) throw new Error(`profile ${r.status}`);
  const data = await r.json();
  return data.emailAddress ?? "";
}
async function signOut() {
  let token;
  try {
    token = (await chrome.identity.getAuthToken({ interactive: false })).token;
  } catch {
    token = void 0;
  }
  if (token) {
    await chrome.identity.removeCachedAuthToken({ token });
    await fetch(`https://oauth2.googleapis.com/revoke?token=${encodeURIComponent(token)}`, {
      method: "POST"
    }).catch(() => void 0);
  }
  await chrome.identity.clearAllCachedAuthTokens();
  await chrome.storage.session.clear();
}
async function authedFetch(url) {
  let token = await getToken(false);
  if (!token) throw new Error("signed-out");
  let r = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
  if (r.status === 401) {
    await chrome.identity.removeCachedAuthToken({ token });
    token = await getToken(false);
    if (!token) throw new Error("signed-out");
    r = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
  }
  return r;
}

// src/background/extract.ts
var KEYWORDS = /\b(code|verification|verify|verifying|otp|one[- ]?time|passcode|pin|2fa|two[- ]factor|security|login|log[- ]in|sign[- ]?in|authenticat\w*|confirm\w*|token)\b/i;
var CANDIDATE = /(?<![\w$€£#.\-])([A-Z0-9]{3,4}[- ][A-Z0-9]{3,4}|[A-Z0-9]{6,8}|\d{4,8})(?![\w%]|\.\d)/g;
function normalise(text) {
  return text.replace(/\s+/g, " ").replace(/\bG-(\d{6,8})\b/g, "$1").replace(/[\u200b\u00a0]/g, " ");
}
function extractCode(text) {
  const clean = normalise(text);
  if (!KEYWORDS.test(clean)) return null;
  let best = null;
  for (const m of clean.matchAll(CANDIDATE)) {
    const raw = m[1];
    const code = raw.replace(/[- ]/g, "");
    const idx = m.index ?? 0;
    let score = 0;
    if (code.length === 6) score += 3;
    else if (code.length >= 4 && code.length <= 8) score += 1;
    else continue;
    const hasDigit = /\d/.test(code);
    const hasLetter = /[A-Z]/.test(code);
    if (!hasDigit && !/[- ]/.test(raw)) continue;
    const before = clean.slice(Math.max(0, idx - 60), idx);
    const after = clean.slice(idx + raw.length, idx + raw.length + 30);
    if (KEYWORDS.test(before)) score += 4;
    if (KEYWORDS.test(after)) score += 2;
    if (/\b(is|:)\s*$/i.test(before)) score += 2;
    if (/^[:\s]*$/.test(before.slice(-2)) && /^\s*(is|will)\b/i.test(after)) score += 1;
    if (/^(19|20)\d{2}$/.test(code)) score -= 4;
    if (/(\$|€|£|usd|total|order|invoice|#)\s*$/i.test(before)) score -= 3;
    if (/https?:\/\/\S*$/.test(before)) score -= 5;
    if (/^\s*(minutes?|mins?|hours?|seconds?|days?)\b/i.test(after)) score -= 4;
    if (/^\d+$/.test(code) && /^\d/.test(after)) score -= 2;
    if (hasLetter && !hasDigit) score -= 3;
    if (/^[A-Z]{2,}\d{0,2}$/.test(code) && !/[- ]/.test(raw)) score -= 3;
    if (!best || score > best.score) best = { code, score };
  }
  return best && best.score >= 4 ? best.code : null;
}

// src/background/gmail.ts
var BASE = "https://gmail.googleapis.com/gmail/v1/users/me";
var QUERY = 'newer_than:10m (code OR verification OR verify OR OTP OR passcode OR "one-time" OR "sign in" OR "log in" OR 2FA)';
var CODE_TTL_MS = 5 * 60 * 1e3;
function header(m, name) {
  const lower = name.toLowerCase();
  return m.payload?.headers?.find((h) => h.name.toLowerCase() === lower)?.value ?? "";
}
function senderDomain(from) {
  const m = from.match(/@([\w.-]+)/);
  if (!m) return "unknown";
  return m[1].toLowerCase().replace(/^(mail|email|e|noreply|no-reply|notifications?|notify|accounts?|auth|security|info|hello|support|alerts?|em|mta|bounce)\./, "").replace(/^(mail|email|noreply|no-reply|notifications?)\./, "");
}
function decodeBase64Url(s) {
  const b64 = s.replace(/-/g, "+").replace(/_/g, "/");
  const bin = atob(b64);
  const bytes = Uint8Array.from(bin, (c) => c.charCodeAt(0));
  return new TextDecoder("utf-8").decode(bytes);
}
function htmlToText(html) {
  return html.replace(/<style[\s\S]*?<\/style>/gi, " ").replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<[^>]+>/g, " ").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&#?\w+;/g, " ");
}
function bodyText(p) {
  if (!p) return "";
  if (p.mimeType === "text/plain" && p.body?.data) return decodeBase64Url(p.body.data);
  if (p.mimeType === "text/html" && p.body?.data) return htmlToText(decodeBase64Url(p.body.data));
  return (p.parts ?? []).map(bodyText).join(" ");
}
function toFound(m, code) {
  const receivedAt = Number(m.internalDate) || Date.now();
  return {
    code,
    sender: senderDomain(header(m, "From")),
    subject: header(m, "Subject").slice(0, 60),
    receivedAt,
    expiresAt: Date.now() + CODE_TTL_MS
  };
}
async function readJson(r, what) {
  if (!r.ok) {
    if (r.status === 403) throw new Error("gmail-forbidden");
    if (r.status === 429) throw new Error("gmail-rate-limited");
    throw new Error(`${what} ${r.status}`);
  }
  return await r.json();
}
async function findLatestCode() {
  const list = await readJson(
    await authedFetch(`${BASE}/messages?maxResults=5&q=${encodeURIComponent(QUERY)}`),
    "list"
  );
  const ids = (list.messages ?? []).map((m) => m.id);
  if (!ids.length) return null;
  const metas = await Promise.all(
    ids.map(
      async (id) => readJson(
        await authedFetch(
          `${BASE}/messages/${id}?format=metadata&metadataHeaders=From&metadataHeaders=Subject`
        ),
        "message"
      )
    )
  );
  metas.sort((a, b) => Number(b.internalDate) - Number(a.internalDate));
  for (const m of metas) {
    const code = extractCode(`${header(m, "Subject")} ${m.snippet ?? ""}`);
    if (code) return toFound(m, code);
  }
  for (const m of metas.slice(0, 2)) {
    const full = await readJson(
      await authedFetch(`${BASE}/messages/${m.id}?format=full`),
      "message"
    );
    const code = extractCode(bodyText(full.payload).slice(0, 6e3));
    if (code) return toFound(m, code);
  }
  return null;
}

// src/shared/types.ts
var DEFAULT_SETTINGS = { autoDetect: true, autoCopy: false };

// src/background/index.ts
var EXPIRE_ALARM = "codesafe-expire-code";
var searching = false;
async function getSettings() {
  const stored = await chrome.storage.sync.get(DEFAULT_SETTINGS);
  return { ...DEFAULT_SETTINGS, ...stored };
}
async function getState() {
  const token = await getToken(false);
  if (!token) return { status: "signed-out" };
  const session = await chrome.storage.session.get(["email", "code", "checkedAt", "error"]);
  let email = session.email ?? "";
  if (!email) {
    email = await getEmail(token).catch(() => "");
    if (email) await chrome.storage.session.set({ email });
  }
  if (searching) return { status: "searching", email };
  if (session.code && session.code.expiresAt > Date.now()) {
    return { status: "found", email, code: session.code };
  }
  if (session.error) return { status: "error", email, message: session.error };
  if (session.checkedAt) return { status: "none", email, checkedAt: session.checkedAt };
  return { status: "idle", email };
}
async function broadcast() {
  const state = await getState();
  const msg = { type: "STATE", payload: state };
  chrome.runtime.sendMessage(msg).catch(() => void 0);
  const tabs = await chrome.tabs.query({ active: true });
  for (const t of tabs) {
    if (t.id !== void 0) chrome.tabs.sendMessage(t.id, msg).catch(() => void 0);
  }
}
function describeError(e) {
  const m = e instanceof Error ? e.message : String(e);
  if (m === "gmail-forbidden") return "Gmail access was denied. Sign out and back in to grant read-only access.";
  if (m === "gmail-rate-limited") return "Gmail is rate-limiting requests. Try again in a minute.";
  return "Couldn't reach Gmail. Check your connection and try again.";
}
async function search(windowMs) {
  if (searching) return;
  searching = true;
  await chrome.storage.session.remove("error");
  await broadcast();
  const start = Date.now();
  let delay = 2e3;
  try {
    while (Date.now() - start < windowMs) {
      const found = await findLatestCode();
      if (found) {
        await chrome.storage.session.set({ code: found, checkedAt: Date.now() });
        chrome.alarms.create(EXPIRE_ALARM, { when: found.expiresAt });
        const { autoCopy } = await getSettings();
        if (autoCopy) await copyViaOffscreen(found.code);
        return;
      }
      await new Promise((r) => setTimeout(r, delay));
      delay = Math.min(delay * 1.5, 5e3);
    }
    await chrome.storage.session.set({ checkedAt: Date.now() });
  } catch (e) {
    if (e instanceof Error && e.message === "signed-out") {
      await chrome.storage.session.clear();
    } else {
      await chrome.storage.session.set({ error: describeError(e) });
    }
  } finally {
    searching = false;
    await broadcast();
  }
}
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== EXPIRE_ALARM) return;
  await chrome.storage.session.remove("code");
  await broadcast();
});
chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  (async () => {
    switch (msg.type) {
      case "GET_STATE":
        reply(await getState());
        break;
      case "SIGN_IN": {
        const token = await getToken(true);
        if (token) {
          const email = await getEmail(token).catch(() => "");
          await chrome.storage.session.set({ email });
        }
        reply(await getState());
        await broadcast();
        break;
      }
      case "SIGN_OUT":
        await signOut();
        reply(await getState());
        await broadcast();
        break;
      case "FETCH_NOW":
        void search(3e4);
        await new Promise((r) => setTimeout(r, 0));
        reply(await getState());
        break;
      case "OTP_FIELD_FOCUSED": {
        const { autoDetect } = await getSettings();
        const current = await getState();
        if (autoDetect && current.status !== "signed-out" && current.status !== "found") {
          void search(9e4);
          await new Promise((r) => setTimeout(r, 0));
        }
        reply(autoDetect ? await getState() : { status: "signed-out" });
        break;
      }
      case "SET_SETTINGS":
        await chrome.storage.sync.set(msg.payload);
        reply(true);
        break;
      default:
        reply(void 0);
    }
  })().catch((e) => {
    console.error("[codesafe]", e);
    reply(void 0);
  });
  return true;
});
chrome.commands.onCommand.addListener(async (command) => {
  if (command !== "paste-latest-code") return;
  const state = await getState();
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (state.status === "found" && tab?.id !== void 0) {
    const msg = { type: "PASTE_CODE", payload: state.code.code };
    chrome.tabs.sendMessage(tab.id, msg).catch(() => void 0);
  } else if (state.status !== "signed-out") {
    void search(3e4);
  }
});
async function copyViaOffscreen(text) {
  try {
    const has = await chrome.offscreen.hasDocument();
    if (!has) {
      await chrome.offscreen.createDocument({
        url: "offscreen.html",
        reasons: [chrome.offscreen.Reason.CLIPBOARD],
        justification: "Copy the verification code to the clipboard"
      });
    }
    const msg = { type: "OFFSCREEN_COPY", payload: text };
    await chrome.runtime.sendMessage(msg);
  } catch (e) {
    console.warn("[codesafe] clipboard copy failed", e);
  }
}
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.get(DEFAULT_SETTINGS).then((s) => chrome.storage.sync.set({ ...DEFAULT_SETTINGS, ...s }));
});
