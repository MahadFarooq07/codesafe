"use strict";
(() => {
  // src/content/detect.ts
  var STRONG_RE = /(otp|one[-_ ]?time|verif|passcode|security[-_ ]?code|auth[-_ ]?code|confirm(ation)?[-_ ]?code|2fa|mfa|totp)/i;
  var WEAK_RE = /(\bpin\b|\bcode\b|\bdigit)/i;
  var NOT_OTP_RE = /(promo|coupon|discount|voucher|gift|referral|invite|zip|postal|post[-_ ]?code|country|area[-_ ]?code|cvv|cvc|csc|iban|swift|sort[-_ ]?code|captcha|search)/i;
  var TEXT_TYPES = /* @__PURE__ */ new Set(["text", "tel", "number", "password"]);
  function isVisible(el) {
    if (!el.isConnected) return false;
    const r = el.getBoundingClientRect();
    if (r.width < 8 || r.height < 8) return false;
    if (typeof el.checkVisibility === "function") {
      return el.checkVisibility({ opacityProperty: true, visibilityProperty: true, contentVisibilityAuto: true });
    }
    const cs = getComputedStyle(el);
    return cs.visibility !== "hidden" && cs.display !== "none" && Number(cs.opacity) > 0.1;
  }
  function isFillable(el) {
    return el instanceof HTMLInputElement && TEXT_TYPES.has(el.type) && !el.disabled && !el.readOnly && isVisible(el);
  }
  function isOtpInput(el) {
    if (!isFillable(el)) return false;
    if (el.autocomplete === "one-time-code") return true;
    const label = [
      el.name,
      el.id,
      el.placeholder,
      el.getAttribute("aria-label"),
      el.getAttribute("aria-labelledby") ? labelledByText(el) : "",
      el.getAttribute("data-testid"),
      el.getAttribute("data-test"),
      typeof el.className === "string" ? el.className : ""
    ].filter(Boolean).join(" ").slice(0, 500);
    const associated = associatedLabelText(el);
    if (STRONG_RE.test(label)) return true;
    if (el.autocomplete && /\b(postal-code|tel|cc-|email|username|current-password|new-password)/.test(el.autocomplete)) return false;
    if (NOT_OTP_RE.test(label) || NOT_OTP_RE.test(associated)) return false;
    if (WEAK_RE.test(label)) return true;
    if (el.inputMode === "numeric" && el.maxLength >= 4 && el.maxLength <= 8) return true;
    if (el.maxLength === 1 && (el.inputMode === "numeric" || el.pattern.includes("0-9") || el.type === "tel")) {
      return otpGroup(el).length >= 4;
    }
    return associated ? STRONG_RE.test(associated) || WEAK_RE.test(associated) : false;
  }
  function labelledByText(el) {
    const ids = (el.getAttribute("aria-labelledby") ?? "").split(/\s+/).slice(0, 5);
    return ids.map((id) => document.getElementById(id)?.textContent ?? "").join(" ").slice(0, 200);
  }
  function associatedLabelText(el) {
    const parts = [];
    el.labels?.forEach((l) => parts.push(l.textContent ?? ""));
    return parts.join(" ").slice(0, 200);
  }
  function singleBoxes(root) {
    return Array.from(root.querySelectorAll("input")).filter(
      (i) => i.maxLength === 1 && TEXT_TYPES.has(i.type) && !i.disabled && isVisible(i)
    );
  }
  function otpGroup(el) {
    if (el.maxLength !== 1) return [el];
    const root = el.form ?? el.closest("fieldset, [role=group], div, section") ?? document.body;
    const boxes = singleBoxes(root);
    if (boxes.length >= 4 && boxes.length <= 8 && boxes.includes(el)) return boxes;
    const parent = root.parentElement;
    if (parent) {
      const wider = singleBoxes(parent);
      if (wider.length >= 4 && wider.length <= 8 && wider.includes(el)) return wider;
    }
    return [el];
  }

  // src/content/fill.ts
  var nativeSetter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")?.set;
  function setValue(input, value) {
    if (nativeSetter) nativeSetter.call(input, value);
    else input.value = value;
    input.dispatchEvent(new InputEvent("input", { bubbles: true, data: value, inputType: "insertText" }));
    input.dispatchEvent(new Event("change", { bubbles: true }));
  }
  function fillBox(box, ch) {
    box.focus();
    box.dispatchEvent(new KeyboardEvent("keydown", { key: ch, bubbles: true }));
    setValue(box, ch);
    box.dispatchEvent(new KeyboardEvent("keyup", { key: ch, bubbles: true }));
  }
  function fillCode(target, code, group) {
    if (!target.isConnected) return;
    if (group.length > 1) {
      const chars = code.split("");
      group.forEach((box, i) => {
        if (i < chars.length && box.isConnected) fillBox(box, chars[i]);
      });
      const last = group[Math.min(chars.length, group.length) - 1];
      last?.focus();
      return;
    }
    target.focus();
    const value = target.maxLength > 0 ? code.slice(0, target.maxLength) : code;
    setValue(target, value);
    try {
      target.setSelectionRange(value.length, value.length);
    } catch {
    }
  }

  // src/shared/tokens.ts
  var TOKENS_CSS = `
:host, :root {
  --bg: #ffffff;
  --bg-page: #fbfdff;
  --bg-hover: #f5f5f7;
  --text: #1b1c1d;
  --text-2: #6e6e73;
  --hairline: rgba(0, 0, 0, 0.08);
  --accent: #0a84ff;
  --success: #34c759;
  --danger: #ff3b30;
  --caution: #b25000;
  --r-input: 12px;
  --r-card: 16px;
  --r-pill: 999px;
  --shadow-float: 0 1px 2px rgba(0, 0, 0, 0.04), 0 8px 24px rgba(0, 0, 0, 0.08);
  --ease: cubic-bezier(0.2, 0.8, 0.2, 1);
  --font: -apple-system, BlinkMacSystemFont, "SF Pro Text", "SF Pro Display", "Helvetica Neue", Inter, "Segoe UI", Roboto, sans-serif;
}
`;

  // src/content/pill.ts
  var CSS = `
${TOKENS_CSS}
:host { all: initial; }
.pill {
  position: fixed;
  z-index: 2147483647;
  display: inline-flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 2px;
  min-width: 96px;
  height: 46px;
  padding: 0 16px;
  margin: 0;
  background: var(--bg);
  color: var(--text);
  border: 0.5px solid rgba(0, 0, 0, 0.12);
  border-radius: 12px;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05), 0 6px 20px rgba(0, 0, 0, 0.10);
  font-family: var(--font);
  -webkit-font-smoothing: antialiased;
  cursor: pointer;
  user-select: none;
  white-space: nowrap;
  text-align: center;
  outline: none;
  opacity: 0;
  transform: translateY(4px) scale(0.98);
  transition: opacity 0.18s var(--ease), transform 0.18s var(--ease), background 0.12s var(--ease);
}
.pill.in { opacity: 1; transform: none; }
.pill:hover { background: var(--bg-hover); }
.pill:focus-visible { box-shadow: 0 0 0 3px rgba(10, 132, 255, 0.35); }
.pill.wait { cursor: default; }
.from { font-size: 11px; line-height: 1; font-weight: 500; color: var(--text-2); letter-spacing: 0; max-width: 220px; overflow: hidden; text-overflow: ellipsis; }
.pill.caution .from { color: var(--caution); }
.code { font-size: 17px; line-height: 1.1; font-weight: 600; letter-spacing: 0.06em; font-variant-numeric: tabular-nums; }
.dots { display: inline-flex; gap: 4px; }
.dots i { width: 5px; height: 5px; border-radius: 50%; background: var(--text-2); opacity: 0.3; animation: codesafe-dot 1.1s infinite var(--ease); }
.dots i:nth-child(2) { animation-delay: 0.15s; }
.dots i:nth-child(3) { animation-delay: 0.3s; }
@keyframes codesafe-dot { 0%, 100% { opacity: 0.25 } 40% { opacity: 0.9 } }
@media (prefers-reduced-motion: reduce) {
  .pill { transition: none; }
  .dots i { animation: none; opacity: 0.6; }
}
`;
  var MIN_DWELL_MS = 500;
  var CONFIRM_DELAY_MS = 600;
  var HOST_STYLE = [
    ["all", "initial"],
    ["position", "fixed"],
    ["inset", "auto"],
    ["top", "0"],
    ["left", "0"],
    ["width", "0"],
    ["height", "0"],
    ["margin", "0"],
    ["padding", "0"],
    ["border", "0"],
    ["background", "transparent"],
    ["overflow", "visible"],
    ["display", "block"],
    ["visibility", "visible"],
    ["opacity", "1"],
    ["filter", "none"],
    ["transform", "none"],
    ["clip-path", "none"],
    ["mask", "none"],
    ["mix-blend-mode", "normal"],
    ["pointer-events", "auto"],
    ["z-index", "2147483647"],
    ["contain", "none"]
  ];
  var sharedSheet = null;
  function sheet() {
    if (sharedSheet) return sharedSheet;
    try {
      sharedSheet = new CSSStyleSheet();
      sharedSheet.replaceSync(CSS);
    } catch {
      sharedSheet = null;
    }
    return sharedSheet;
  }
  function span(cls, text) {
    const s = document.createElement("span");
    s.className = cls;
    s.textContent = text;
    return s;
  }
  var Pill = class {
    constructor(anchor, onPick) {
      this.anchor = anchor;
      this.onPick = onPick;
      const adopted = sheet();
      if (adopted) {
        this.root.adoptedStyleSheets = [adopted];
      } else {
        const style = document.createElement("style");
        style.textContent = CSS;
        this.root.append(style);
      }
      this.el.className = "pill";
      this.el.type = "button";
      this.el.setAttribute("aria-live", "polite");
      this.el.addEventListener("mousedown", (e) => e.preventDefault());
      this.el.addEventListener("click", this.handleClick);
      this.root.append(this.el);
      this.applyHostStyle();
      this.host.setAttribute("popover", "manual");
      document.documentElement.append(this.host);
      try {
        this.host.showPopover();
      } catch {
      }
      this.host.addEventListener("toggle", (e) => {
        if (e.newState === "closed") this.destroy();
      });
      this.tamperGuard = new MutationObserver(() => this.destroy());
      this.tamperGuard.observe(this.host, { attributes: true });
      try {
        this.visibility = new IntersectionObserver(
          (entries) => {
            for (const e of entries) {
              const v = e.isVisible;
              this.visibleToUser = typeof v === "boolean" ? v : null;
            }
          },
          { threshold: [1], trackVisibility: true, delay: 100 }
        );
        this.visibility.observe(this.el);
      } catch {
        this.visibility = null;
      }
      this.position();
      window.addEventListener("scroll", this.position, true);
      window.addEventListener("resize", this.position);
    }
    anchor;
    onPick;
    host = document.createElement("codesafe-pill");
    root = this.host.attachShadow({ mode: "closed" });
    el = document.createElement("button");
    removed = false;
    shownAt = 0;
    visibleToUser = null;
    // null = browser can't tell us
    caution = false;
    confirmedAt = 0;
    tamperGuard;
    visibility = null;
    applyHostStyle() {
      for (const [k, v] of HOST_STYLE) this.host.style.setProperty(k, v, "important");
    }
    searching() {
      this.caution = false;
      this.el.className = "pill wait";
      this.el.setAttribute("aria-label", "Checking Gmail for a code");
      const dots = document.createElement("span");
      dots.className = "dots";
      dots.setAttribute("aria-hidden", "true");
      dots.append(document.createElement("i"), document.createElement("i"), document.createElement("i"));
      this.el.replaceChildren(dots);
      this.show();
    }
    /**
     * @param trusted the sender's site matches this page and Gmail verified the
     *   sender. Otherwise the pill shows in a cautionary colour and needs two clicks.
     */
    found(code, sender, trusted) {
      const wasVisible = this.el.classList.contains("in") && !this.el.classList.contains("wait");
      this.caution = !trusted;
      this.confirmedAt = 0;
      this.el.className = trusted ? "pill" : "pill caution";
      const from = trusted ? `From ${sender}` : `From ${sender} \xB7 not this site`;
      this.el.setAttribute(
        "aria-label",
        trusted ? `Paste code ${code} from ${sender}` : `Code ${code} is from ${sender}, not this site. Click twice to paste.`
      );
      this.el.replaceChildren(span("from", from), span("code", code));
      if (!wasVisible) this.shownAt = 0;
      this.show();
    }
    show() {
      requestAnimationFrame(() => {
        if (this.removed) return;
        this.el.classList.add("in");
        if (!this.shownAt) this.shownAt = performance.now();
      });
      this.position();
    }
    handleClick = (e) => {
      if (this.removed || !e.isTrusted) return;
      if (this.el.classList.contains("wait")) return;
      const now = performance.now();
      if (!this.shownAt || now - this.shownAt < MIN_DWELL_MS) return;
      if (this.visibleToUser === false) return;
      if (e.clientX || e.clientY) {
        const hit = document.elementFromPoint(e.clientX, e.clientY);
        if (hit !== this.host) return;
      }
      if (this.caution) {
        if (!this.confirmedAt) {
          this.confirmedAt = now;
          const from = this.el.querySelector(".from");
          if (from) from.textContent = "Not this site \xB7 click again to paste";
          return;
        }
        if (now - this.confirmedAt < CONFIRM_DELAY_MS) return;
      }
      this.onPick();
    };
    position = () => {
      if (this.removed) return;
      if (!this.anchor.isConnected) {
        this.destroy();
        return;
      }
      const r = this.anchor.getBoundingClientRect();
      const h = 46;
      const gap = 8;
      let top = r.top - h - gap;
      if (top < 8) top = r.bottom + gap;
      const left = Math.max(8, Math.min(r.left, window.innerWidth - 8 - this.el.offsetWidth));
      this.el.style.left = `${left}px`;
      this.el.style.top = `${top}px`;
    };
    destroy() {
      if (this.removed) return;
      this.removed = true;
      this.tamperGuard.disconnect();
      this.visibility?.disconnect();
      window.removeEventListener("scroll", this.position, true);
      window.removeEventListener("resize", this.position);
      this.el.classList.remove("in");
      this.el.replaceChildren();
      setTimeout(() => this.host.remove(), 200);
    }
    get isDestroyed() {
      return this.removed;
    }
  };

  // src/shared/types.ts
  var CODE_RE = /^[A-Z0-9]{4,8}$/;
  var DEFAULT_SETTINGS = { autoDetect: true, autoCopy: false };
  var SETTING_KEYS = Object.keys(DEFAULT_SETTINGS);

  // src/content/index.ts
  var active = null;
  function send(msg) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(msg, (r) => {
          void chrome.runtime.lastError;
          resolve(r);
        });
      } catch {
        resolve(void 0);
      }
    });
  }
  function clear() {
    if (!active) return;
    active.pill.destroy();
    active = null;
    void send({ type: "FIELD_BLURRED" });
  }
  function render(state) {
    if (!active || active.pill.isDestroyed) return;
    if (!state || state.status === "hidden") {
      clear();
      return;
    }
    active.state = state;
    if (state.status === "searching") active.pill.searching();
    else if (CODE_RE.test(state.code)) active.pill.found(state.code, state.sender, state.trusted);
    else clear();
  }
  function stillFocused(a) {
    const el = document.activeElement;
    return el instanceof HTMLInputElement && (el === a.input || a.group.includes(el)) && a.input.isConnected;
  }
  async function pick() {
    const current = active;
    if (!current || current.state.status !== "found") return;
    const reply = await send({ type: "FILL_REQUEST" });
    const code = reply?.code;
    if (!code || !CODE_RE.test(code)) return;
    if (active !== current || !stillFocused(current)) return;
    fillCode(current.input, code, current.group);
    current.pill.destroy();
    active = null;
  }
  function attach(input) {
    clear();
    const group = otpGroup(input);
    const pill = new Pill(input, () => void pick());
    active = { input, group, pill, state: { status: "hidden" } };
    return active;
  }
  document.addEventListener(
    "focusin",
    (e) => {
      const t = e.target;
      if (!isOtpInput(t)) return;
      if (active && !active.pill.isDestroyed && (active.input === t || active.group.includes(t))) return;
      const a = attach(t);
      void send({ type: "FIELD_FOCUSED" }).then((s) => {
        if (active === a) render(s);
      });
    },
    true
  );
  document.addEventListener(
    "focusout",
    () => {
      setTimeout(() => {
        if (!active) return;
        const el = document.activeElement;
        if (!(el instanceof HTMLInputElement) || !active.group.includes(el)) clear();
      }, 150);
    },
    true
  );
  window.addEventListener("pagehide", clear);
  async function onPasteRequest() {
    if (!document.hasFocus()) return;
    const el = document.activeElement;
    if (!isFillable(el)) return;
    const a = active && !active.pill.isDestroyed && (active.input === el || active.group.includes(el)) ? active : attach(el);
    const state = await send({ type: "FIELD_FOCUSED", explicit: true });
    if (active !== a) return;
    render(state);
    if (state?.status === "found" && state.trusted) await pick();
  }
  chrome.runtime.onMessage.addListener((msg, sender) => {
    if (sender.id !== chrome.runtime.id || sender.tab) return;
    if (msg?.type === "PILL_STATE") render(msg.payload);
    else if (msg?.type === "PASTE_REQUEST") void onPasteRequest();
  });
})();
