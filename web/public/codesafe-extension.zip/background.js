// src/background/auth.ts
var SCOPE = "https://www.googleapis.com/auth/gmail.readonly";
var WEB_CLIENT_ID = true ? "" : "";
async function chromeToken(interactive) {
  try {
    const { token, grantedScopes } = await chrome.identity.getAuthToken({ interactive, scopes: [SCOPE] });
    if (!token) return null;
    if (grantedScopes && !grantedScopes.includes(SCOPE)) return null;
    return token;
  } catch {
    return null;
  }
}
async function readWebToken() {
  const { webToken } = await chrome.storage.session.get("webToken");
  if (webToken && webToken.expiresAt - 6e4 > Date.now()) return webToken.token;
  return null;
}
async function verifyWebToken(token) {
  const r = await fetch("https://oauth2.googleapis.com/tokeninfo", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ access_token: token })
  }).catch(() => null);
  if (!r?.ok) return false;
  const info = await r.json();
  const audience = info.aud ?? info.azp;
  return audience === WEB_CLIENT_ID && (info.scope ?? "").split(" ").includes(SCOPE);
}
async function webFlowToken(interactive) {
  if (!WEB_CLIENT_ID) return null;
  const cached = await readWebToken();
  if (cached) return cached;
  const state = crypto.randomUUID();
  const auth = new URL("https://accounts.google.com/o/oauth2/v2/auth");
  auth.search = new URLSearchParams({
    client_id: WEB_CLIENT_ID,
    response_type: "token",
    redirect_uri: chrome.identity.getRedirectURL(),
    scope: SCOPE,
    state,
    include_granted_scopes: "false",
    ...interactive ? { prompt: "select_account" } : { prompt: "none" }
  }).toString();
  let redirect;
  try {
    redirect = await chrome.identity.launchWebAuthFlow({ url: auth.toString(), interactive });
  } catch {
    return null;
  }
  if (!redirect || !redirect.startsWith(chrome.identity.getRedirectURL())) return null;
  const params = new URLSearchParams(new URL(redirect).hash.slice(1));
  if (params.get("state") !== state) return null;
  const token = params.get("access_token");
  const expiresIn = Number(params.get("expires_in") ?? "0");
  if (!token || !(expiresIn > 0)) return null;
  if (!await verifyWebToken(token)) return null;
  const webToken = { token, expiresAt: Date.now() + expiresIn * 1e3 };
  await chrome.storage.session.set({ webToken });
  return token;
}
async function getToken(interactive) {
  const viaChrome = await chromeToken(interactive);
  if (viaChrome) return viaChrome;
  return webFlowToken(interactive);
}
async function invalidate(token) {
  await chrome.identity.removeCachedAuthToken({ token }).catch(() => void 0);
  const { webToken } = await chrome.storage.session.get("webToken");
  if (webToken?.token === token) await chrome.storage.session.remove("webToken");
}
async function revoke(token) {
  await fetch("https://oauth2.googleapis.com/revoke", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ token })
  }).catch(() => void 0);
}
async function signOut() {
  const tokens = /* @__PURE__ */ new Set();
  const chromeTok = await chromeToken(false);
  if (chromeTok) tokens.add(chromeTok);
  const webTok = await readWebToken();
  if (webTok) tokens.add(webTok);
  for (const token of tokens) {
    await invalidate(token);
    await revoke(token);
  }
  await chrome.identity.clearAllCachedAuthTokens().catch(() => void 0);
  await chrome.storage.session.clear();
}
async function authedFetch(url) {
  let token = await getToken(false);
  if (!token) throw new Error("signed-out");
  const init = (t) => ({
    headers: { Authorization: `Bearer ${t}` },
    credentials: "omit",
    cache: "no-store",
    referrerPolicy: "no-referrer"
  });
  let r = await fetch(url, init(token));
  if (r.status === 401) {
    await invalidate(token);
    token = await getToken(false);
    if (!token) throw new Error("signed-out");
    r = await fetch(url, init(token));
  }
  return r;
}
async function getEmail() {
  const r = await authedFetch("https://gmail.googleapis.com/gmail/v1/users/me/profile");
  if (!r.ok) throw new Error(`profile ${r.status}`);
  const data = await r.json();
  return typeof data.emailAddress === "string" ? data.emailAddress.slice(0, 254) : "";
}

// src/background/extract.ts
var KEYWORDS = /\b(code|verification|verify|verifying|otp|one[- ]?time|passcode|pin|2fa|two[- ]factor|security|login|log[- ]in|sign[- ]?in|authenticat\w*|confirm\w*|token)\b/i;
var CANDIDATE = /(?<![\w$€£#.\-])([A-Z0-9]{3,4}[- ][A-Z0-9]{3,4}|[A-Z0-9]{6,8}|\d{4,8})(?![\w%]|\.\d)/g;
function normalise(text) {
  return text.replace(/\s+/g, " ").replace(/\bG-(\d{6,8})\b/g, "$1").replace(/[\u200b\u00a0]/g, " ");
}
function extractCode(text) {
  const clean = normalise(text);
  if (!KEYWORDS.test(clean)) return null;
  let best = null;
  for (const m of clean.matchAll(CANDIDATE)) {
    const raw = m[1];
    const code = raw.replace(/[- ]/g, "");
    const idx = m.index ?? 0;
    let score = 0;
    if (code.length === 6) score += 3;
    else if (code.length >= 4 && code.length <= 8) score += 1;
    else continue;
    const hasDigit = /\d/.test(code);
    const hasLetter = /[A-Z]/.test(code);
    if (!hasDigit && !/[- ]/.test(raw)) continue;
    const before = clean.slice(Math.max(0, idx - 60), idx);
    const after = clean.slice(idx + raw.length, idx + raw.length + 30);
    if (KEYWORDS.test(before)) score += 4;
    if (KEYWORDS.test(after)) score += 2;
    if (/\b(is|:)\s*$/i.test(before)) score += 2;
    if (/^[:\s]*$/.test(before.slice(-2)) && /^\s*(is|will)\b/i.test(after)) score += 1;
    if (/^(19|20)\d{2}$/.test(code)) score -= 4;
    if (/(\$|€|£|usd|total|order|invoice|#)\s*$/i.test(before)) score -= 3;
    if (/https?:\/\/\S*$/.test(before)) score -= 5;
    if (/^\s*(minutes?|mins?|hours?|seconds?|days?)\b/i.test(after)) score -= 4;
    if (/^\d+$/.test(code) && /^\d/.test(after)) score -= 2;
    if (hasLetter && !hasDigit) score -= 3;
    if (/^[A-Z]{2,}\d{0,2}$/.test(code) && !/[- ]/.test(raw)) score -= 3;
    if (!best || score > best.score) best = { code, score };
  }
  return best && best.score >= 4 ? best.code : null;
}

// src/shared/site.ts
var MULTI_PART_SUFFIXES = /* @__PURE__ */ new Set([
  "co.uk",
  "org.uk",
  "ac.uk",
  "gov.uk",
  "me.uk",
  "ltd.uk",
  "plc.uk",
  "com.au",
  "net.au",
  "org.au",
  "edu.au",
  "gov.au",
  "co.nz",
  "org.nz",
  "net.nz",
  "co.jp",
  "ne.jp",
  "or.jp",
  "ac.jp",
  "co.kr",
  "or.kr",
  "com.br",
  "net.br",
  "org.br",
  "com.cn",
  "net.cn",
  "org.cn",
  "com.mx",
  "com.ar",
  "com.co",
  "com.tr",
  "com.sg",
  "com.my",
  "com.hk",
  "com.tw",
  "co.in",
  "net.in",
  "org.in",
  "firm.in",
  "gen.in",
  "ind.in",
  "co.za",
  "org.za",
  "com.pk",
  "net.pk",
  "org.pk",
  "co.id",
  "or.id",
  "web.id",
  "com.ph",
  "com.vn",
  "com.sa",
  "com.eg",
  "com.ng",
  "co.il",
  "co.th"
]);
function siteOf(hostname) {
  const host = hostname.toLowerCase().replace(/\.$/, "");
  if (!host || /^[\d.]+$/.test(host) || host.includes(":")) return host;
  const labels = host.split(".");
  if (labels.length <= 2) return host;
  const lastTwo = labels.slice(-2).join(".");
  if (MULTI_PART_SUFFIXES.has(lastTwo)) return labels.slice(-3).join(".");
  return lastTwo;
}
function hostOf(url) {
  if (!url) return "";
  try {
    const u = new URL(url);
    return u.protocol === "https:" || u.protocol === "http:" ? u.hostname : "";
  } catch {
    return "";
  }
}
function sameSite(senderDomain2, pageHost) {
  if (!senderDomain2 || !pageHost) return false;
  return siteOf(senderDomain2) === siteOf(pageHost);
}

// src/shared/types.ts
var CODE_RE = /^[A-Z0-9]{4,8}$/;
var DEFAULT_SETTINGS = { autoDetect: true, autoCopy: false };
var SETTING_KEYS = Object.keys(DEFAULT_SETTINGS);

// src/background/gmail.ts
var BASE = "https://gmail.googleapis.com/gmail/v1/users/me";
var WINDOW_MS = 10 * 60 * 1e3;
var QUERY = 'newer_than:10m -in:spam -in:trash (code OR verification OR verify OR OTP OR passcode OR "one-time" OR "sign in" OR "log in" OR 2FA)';
var CODE_TTL_MS = 5 * 60 * 1e3;
function header(m, name) {
  const lower = name.toLowerCase();
  return m.payload?.headers?.find((h) => h.name.toLowerCase() === lower)?.value ?? "";
}
function senderDomain(from) {
  const angle = from.match(/<([^<>]*)>\s*$/);
  const addr = angle ? angle[1] : from;
  const m = addr.match(/@([a-z0-9.-]+)\s*$/i);
  if (!m) return "unknown";
  return siteOf(m[1]);
}
function isVerifiedSender(authResults, domain) {
  const v = authResults.toLowerCase();
  if (!v.startsWith("mx.google.com")) return false;
  const dmarc = v.match(/\bdmarc=(\w+)[^;]*?header\.from=([a-z0-9.-]+)/);
  if (dmarc) return dmarc[1] === "pass" && siteOf(dmarc[2]) === domain;
  const dkim = v.match(/\bdkim=pass[^;]*?header\.(?:i|d)=@?([a-z0-9.-]+)/);
  return !!dkim && siteOf(dkim[1]) === domain;
}
function decodeBase64Url(s) {
  const b64 = s.replace(/-/g, "+").replace(/_/g, "/");
  const bin = atob(b64);
  const bytes = Uint8Array.from(bin, (c) => c.charCodeAt(0));
  return new TextDecoder("utf-8").decode(bytes);
}
function htmlToText(html) {
  return html.replace(/<style[\s\S]*?<\/style>/gi, " ").replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<[^>]+>/g, " ").replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&#?\w+;/g, " ");
}
function bodyText(p, depth = 0) {
  if (!p || depth > 8) return "";
  if (p.mimeType === "text/plain" && p.body?.data) return decodeBase64Url(p.body.data);
  if (p.mimeType === "text/html" && p.body?.data) return htmlToText(decodeBase64Url(p.body.data));
  return (p.parts ?? []).map((part) => bodyText(part, depth + 1)).join(" ");
}
function toFound(m, code) {
  if (!CODE_RE.test(code)) return null;
  const receivedAt = Number(m.internalDate) || Date.now();
  const sender = senderDomain(header(m, "From"));
  return {
    code,
    sender,
    verified: isVerifiedSender(header(m, "Authentication-Results"), sender),
    messageId: m.id,
    receivedAt,
    expiresAt: Date.now() + CODE_TTL_MS
  };
}
async function readJson(r, what) {
  if (!r.ok) {
    if (r.status === 403) throw new Error("gmail-forbidden");
    if (r.status === 429) throw new Error("gmail-rate-limited");
    throw new Error(`${what} ${r.status}`);
  }
  return await r.json();
}
var ID_RE = /^[a-zA-Z0-9]{1,64}$/;
async function findLatestCode(usedIds) {
  const list = await readJson(
    await authedFetch(`${BASE}/messages?maxResults=5&q=${encodeURIComponent(QUERY)}`),
    "list"
  );
  const ids = (list.messages ?? []).map((m) => m.id).filter((id) => typeof id === "string" && ID_RE.test(id) && !usedIds.has(id));
  if (!ids.length) return null;
  const metas = await Promise.all(
    ids.map(
      async (id) => readJson(
        await authedFetch(
          `${BASE}/messages/${id}?format=metadata&metadataHeaders=From&metadataHeaders=Subject&metadataHeaders=Authentication-Results`
        ),
        "message"
      )
    )
  );
  const cutoff = Date.now() - WINDOW_MS;
  const recent = metas.filter((m) => Number(m.internalDate) >= cutoff).sort((a, b) => Number(b.internalDate) - Number(a.internalDate));
  for (const m of recent) {
    const code = extractCode(`${header(m, "Subject")} ${m.snippet ?? ""}`);
    const found = code ? toFound(m, code) : null;
    if (found) return found;
  }
  for (const m of recent.slice(0, 2)) {
    const full = await readJson(
      await authedFetch(`${BASE}/messages/${m.id}?format=full`),
      "message"
    );
    const code = extractCode(bodyText(full.payload).slice(0, 6e3));
    const found = code ? toFound(m, code) : null;
    if (found) return found;
  }
  return null;
}

// src/background/index.ts
var EXPIRE_ALARM = "codesafe-expire-code";
var EXT_URL = chrome.runtime.getURL("");
var CONTENT_SEARCH_COOLDOWN_MS = 2e4;
var FOCUS_TTL_MS = 10 * 60 * 1e3;
var MAX_USED_IDS = 50;
void chrome.storage.session.setAccessLevel({ accessLevel: "TRUSTED_CONTEXTS" }).catch(() => void 0);
var searching = false;
var lastContentSearch = 0;
async function session() {
  return await chrome.storage.session.get(["email", "code", "checkedAt", "error", "usedIds", "focus"]);
}
async function getSettings() {
  const stored = await chrome.storage.sync.get(DEFAULT_SETTINGS);
  return {
    autoDetect: typeof stored.autoDetect === "boolean" ? stored.autoDetect : DEFAULT_SETTINGS.autoDetect,
    autoCopy: typeof stored.autoCopy === "boolean" ? stored.autoCopy : DEFAULT_SETTINGS.autoCopy
  };
}
function liveCode(s) {
  const c = s.code;
  return c && c.expiresAt > Date.now() && CODE_RE.test(c.code) ? c : null;
}
async function getState() {
  const token = await getToken(false);
  if (!token) return { status: "signed-out" };
  const s = await session();
  let email = s.email ?? "";
  if (!email) {
    email = await getEmail().catch(() => "");
    if (email) await chrome.storage.session.set({ email });
  }
  if (searching) return { status: "searching", email };
  const code = liveCode(s);
  if (code) return { status: "found", email, code };
  if (s.error) return { status: "error", email, message: s.error };
  if (s.checkedAt) return { status: "none", email, checkedAt: s.checkedAt };
  return { status: "idle", email };
}
function trustedFor(code, focus) {
  if (!code.verified) return false;
  if (!sameSite(code.sender, focus.frameHost)) return false;
  return !focus.topHost || sameSite(code.sender, focus.topHost);
}
async function pillStateFor(focus) {
  if (!focus) return { status: "hidden" };
  if (searching) return { status: "searching" };
  const code = liveCode(await session());
  if (!code) return { status: "hidden" };
  return { status: "found", code: code.code, sender: code.sender, trusted: trustedFor(code, focus) };
}
async function broadcast() {
  const toPopup = { type: "STATE", payload: await getState() };
  chrome.runtime.sendMessage(toPopup).catch(() => void 0);
  const { focus } = await session();
  if (!focus) return;
  const toFrame = { type: "PILL_STATE", payload: await pillStateFor(focus) };
  chrome.tabs.sendMessage(focus.tabId, toFrame, { frameId: focus.frameId }).catch(() => void 0);
}
function describeError(e) {
  const m = e instanceof Error ? e.message : String(e);
  if (m === "gmail-forbidden") return "Gmail access was denied. Sign out and back in to grant read-only access.";
  if (m === "gmail-rate-limited") return "Gmail is rate-limiting requests. Try again in a minute.";
  return "Couldn't reach Gmail. Check your connection and try again.";
}
async function search(windowMs) {
  if (searching) return;
  searching = true;
  await chrome.storage.session.remove("error");
  await broadcast();
  const start = Date.now();
  let delay = 2e3;
  try {
    while (Date.now() - start < windowMs) {
      const { usedIds = [] } = await session();
      const found = await findLatestCode(new Set(usedIds));
      if (found) {
        await chrome.storage.session.set({ code: found, checkedAt: Date.now() });
        await chrome.alarms.create(EXPIRE_ALARM, { when: found.expiresAt });
        const { autoCopy } = await getSettings();
        if (autoCopy) await copyViaOffscreen(found.code);
        return;
      }
      await new Promise((r) => setTimeout(r, delay));
      delay = Math.min(delay * 1.5, 5e3);
    }
    await chrome.storage.session.set({ checkedAt: Date.now() });
  } catch (e) {
    if (e instanceof Error && e.message === "signed-out") {
      await chrome.storage.session.clear();
    } else {
      await chrome.storage.session.set({ error: describeError(e) });
    }
  } finally {
    searching = false;
    await broadcast();
  }
}
async function consumeCode(code) {
  const { usedIds = [] } = await session();
  const next = [code.messageId, ...usedIds.filter((id) => id !== code.messageId)].slice(0, MAX_USED_IDS);
  await chrome.storage.session.set({ usedIds: next });
  await chrome.storage.session.remove(["code", "checkedAt"]);
  await chrome.alarms.clear(EXPIRE_ALARM);
}
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== EXPIRE_ALARM) return;
  await chrome.storage.session.remove("code");
  await broadcast();
});
function isExtensionPage(s) {
  return s.id === chrome.runtime.id && typeof s.url === "string" && s.url.startsWith(EXT_URL);
}
function isContentScript(s) {
  return s.id === chrome.runtime.id && typeof s.tab?.id === "number" && typeof s.frameId === "number" && !(s.url ?? "").startsWith(EXT_URL);
}
function isMsg(m) {
  return typeof m === "object" && m !== null && typeof m.type === "string";
}
function sanitizeSettings(p) {
  const out = {};
  if (typeof p !== "object" || p === null) return out;
  for (const k of SETTING_KEYS) {
    const v = p[k];
    if (typeof v === "boolean") out[k] = v;
  }
  return out;
}
async function handlePopup(msg) {
  switch (msg.type) {
    case "GET_STATE":
      return getState();
    case "SIGN_IN": {
      const token = await getToken(true);
      if (token) {
        const email = await getEmail().catch(() => "");
        await chrome.storage.session.set({ email });
      }
      void broadcast();
      return getState();
    }
    case "SIGN_OUT":
      await signOut();
      await chrome.alarms.clear(EXPIRE_ALARM);
      void broadcast();
      return getState();
    case "FETCH_NOW":
      void search(3e4);
      await new Promise((r) => setTimeout(r, 0));
      return getState();
    case "SET_SETTINGS":
      await chrome.storage.sync.set(sanitizeSettings(msg.payload));
      return true;
    default:
      return void 0;
  }
}
async function handleContent(msg, sender) {
  const tabId = sender.tab.id;
  const frameId = sender.frameId;
  switch (msg.type) {
    case "FIELD_FOCUSED": {
      const { autoDetect } = await getSettings();
      if (!autoDetect && msg.explicit !== true) return { status: "hidden" };
      if (!await getToken(false)) return { status: "hidden" };
      const focus = {
        tabId,
        frameId,
        frameHost: hostOf(sender.url) || hostOf(sender.origin),
        topHost: hostOf(sender.tab.url),
        at: Date.now()
      };
      if (!focus.frameHost) return { status: "hidden" };
      await chrome.storage.session.set({ focus });
      const s = await session();
      if (!liveCode(s) && !searching && Date.now() - lastContentSearch > CONTENT_SEARCH_COOLDOWN_MS) {
        lastContentSearch = Date.now();
        void search(9e4);
        await new Promise((r) => setTimeout(r, 0));
      }
      return pillStateFor(focus);
    }
    case "FIELD_BLURRED": {
      const { focus } = await session();
      if (focus && focus.tabId === tabId && focus.frameId === frameId) {
        await chrome.storage.session.remove("focus");
      }
      return void 0;
    }
    case "FILL_REQUEST": {
      const s = await session();
      const focus = s.focus;
      if (!focus || focus.tabId !== tabId || focus.frameId !== frameId) return { code: null };
      if (Date.now() - focus.at > FOCUS_TTL_MS) return { code: null };
      const code = liveCode(s);
      if (!code) return { code: null };
      await consumeCode(code);
      await chrome.storage.session.remove("focus");
      void broadcast();
      return { code: code.code };
    }
    default:
      return void 0;
  }
}
var POPUP_TYPES = /* @__PURE__ */ new Set(["GET_STATE", "SIGN_IN", "SIGN_OUT", "FETCH_NOW", "SET_SETTINGS"]);
var CONTENT_TYPES = /* @__PURE__ */ new Set(["FIELD_FOCUSED", "FIELD_BLURRED", "FILL_REQUEST"]);
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (!isMsg(msg)) return false;
  let work = null;
  if (isExtensionPage(sender) && POPUP_TYPES.has(msg.type)) {
    work = handlePopup(msg);
  } else if (isContentScript(sender) && CONTENT_TYPES.has(msg.type)) {
    work = handleContent(msg, sender);
  }
  if (!work) return false;
  work.then(reply, (e) => {
    console.error("[codesafe]", e);
    reply(void 0);
  });
  return true;
});
chrome.runtime.onMessageExternal?.addListener(() => false);
chrome.runtime.onConnectExternal?.addListener((port) => port.disconnect());
chrome.tabs.onRemoved.addListener(async (tabId) => {
  const { focus } = await session();
  if (focus?.tabId === tabId) await chrome.storage.session.remove("focus");
});
chrome.commands.onCommand.addListener(async (command) => {
  if (command !== "paste-latest-code") return;
  if (!await getToken(false)) return;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab?.id === void 0) return;
  const msg = { type: "PASTE_REQUEST" };
  chrome.tabs.sendMessage(tab.id, msg).catch(() => void 0);
  if (!liveCode(await session())) void search(3e4);
});
async function copyViaOffscreen(text) {
  if (!CODE_RE.test(text)) return;
  try {
    const has = await chrome.offscreen.hasDocument();
    if (!has) {
      await chrome.offscreen.createDocument({
        url: "offscreen.html",
        reasons: [chrome.offscreen.Reason.CLIPBOARD],
        justification: "Copy the verification code to the clipboard"
      });
    }
    const msg = { type: "OFFSCREEN_COPY", payload: text };
    await chrome.runtime.sendMessage(msg);
  } catch (e) {
    console.warn("[codesafe] clipboard copy failed", e);
  } finally {
    await chrome.offscreen.closeDocument().catch(() => void 0);
  }
}
chrome.runtime.onInstalled.addListener(async () => {
  const s = await getSettings();
  await chrome.storage.sync.set(s);
});
