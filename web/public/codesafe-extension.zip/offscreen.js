"use strict";
(() => {
  // src/shared/types.ts
  var CODE_RE = /^[A-Z0-9]{4,8}$/;
  var DEFAULT_SETTINGS = { autoDetect: true, autoCopy: false };
  var SETTING_KEYS = Object.keys(DEFAULT_SETTINGS);

  // src/background/offscreen.ts
  var EXT_URL = chrome.runtime.getURL("");
  chrome.runtime.onMessage.addListener((msg, sender, reply) => {
    if (msg?.type !== "OFFSCREEN_COPY") return false;
    if (sender.id !== chrome.runtime.id || sender.tab || !(sender.url ?? "").startsWith(EXT_URL)) return false;
    if (typeof msg.payload !== "string" || !CODE_RE.test(msg.payload)) return false;
    const ta = document.createElement("textarea");
    ta.value = msg.payload;
    document.body.append(ta);
    ta.select();
    document.execCommand("copy");
    ta.value = "";
    ta.remove();
    reply(true);
    return false;
  });
})();
